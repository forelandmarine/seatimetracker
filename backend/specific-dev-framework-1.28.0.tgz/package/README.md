# @specific-dev/framework

A TypeScript framework for building backend applications with Fastify, featuring built-in authentication, storage, database, and AI integrations.

## Installation

```bash
npm install @specific-dev/framework
```

## Quick Start

```typescript
import { createApplication } from "@specific-dev/framework";
import * as schema from "./db/schema.js";

const app = await createApplication(schema);

app.fastify.get("/users", async () => {
  return app.db.select().from(schema.users);
});

await app.run();
```

## Features

### Database

Built on [Drizzle ORM](https://orm.drizzle.team/) with PostgreSQL:

```typescript
// src/db/schema.ts
import { pgTable, uuid, text, timestamp } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
```

```typescript
// Query using app.db
const users = await app.db.select().from(schema.users);
const user = await app.db.query.users.findFirst({
  where: eq(schema.users.id, userId),
});
```

### Authentication

Built on [Better Auth](https://www.better-auth.com/):

```bash
npx @specific-dev/framework copy-auth-schema --dir ./src/db
```

```typescript
import * as appSchema from "./db/schema.js";
import * as authSchema from "./db/auth-schema.js";

const schema = { ...appSchema, ...authSchema };
const app = await createApplication(schema);

app.withAuth({
  socialProviders: {
    google: {
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    },
  },
});
```

Protect routes:

```typescript
const requireAuth = app.requireAuth();

app.fastify.get("/me", async (request, reply) => {
  const session = await requireAuth(request, reply);
  if (!session) return;
  return { user: session.user };
});
```

### Storage

S3-compatible file storage:

```typescript
app.withStorage();

app.fastify.post("/upload", async (request, reply) => {
  const file = await request.file();
  if (!file) return reply.status(400).send({ error: "No file" });

  const buffer = await file.toBuffer();
  const key = await app.storage.upload(`uploads/${file.filename}`, buffer);
  const { url } = await app.storage.getSignedUrl(key);

  return { url, key };
});
```

### AI Gateway

Integration with [Vercel AI SDK](https://sdk.vercel.ai/) using [Vercel AI Gateway](https://sdk.vercel.ai/docs/ai-sdk-core/ai-gateway):

```typescript
import { gateway } from "@specific-dev/framework";
import { generateText } from "ai";

const { text } = await generateText({
  model: gateway("openai/gpt-4o"),
  prompt: "Hello!",
});
```

## Environment Variables

| Variable | Description |
|----------|-------------|
| `DATABASE_URL` | PostgreSQL connection string |
| `BETTER_AUTH_SECRET` | Auth session secret |
| `AWS_S3_BUCKET` | S3 bucket (direct mode) |
| `AWS_REGION` | AWS region (direct mode) |
| `STORAGE_API_BASE_URL` | Storage proxy URL (proxy mode) |
| `AI_GATEWAY_API_KEY` | Vercel AI Gateway API key |

## License

ISC
