/**
 * Lambda handler entry point
 *
 * This file is copied by the framework during Lambda deployment.
 * It imports index.js to initialize the app, then creates the Lambda handler.
 */
import { createLambdaHandler } from '@specific-dev/framework';

// Import to initialize the application
await import('./index.js');

// Export Lambda handler
export const handler = await createLambdaHandler();
